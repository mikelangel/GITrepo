package com.corvo.blocdenotas.activities;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.corvo.blocdenotas.R;
import com.corvo.blocdenotas.adapters.ListaPrincipalAdapter;
import com.corvo.blocdenotas.beans.Tarea;
import com.corvo.blocdenotas.db.DbAdapter;
import com.corvo.blocdenotas.utils.ConversoresUtils;
import com.corvo.blocdenotas.utils.HorizontalPager;

/**
 * Main application activity. It's goal is to show all tasks, divided by day and allow scroll through them by touch movement. 
 * It has a lower menu to add a new task  and it possible to select a task to modify it or delete it.
 * In both cases, the application redirects the activity NuevaTareaActivity.
 * 
 * @author Miguel Corvo Diaz
 * @version 0.1.3
 */
public class PrincipalActivity extends Activity {
	ArrayList<Tarea> list = new ArrayList<Tarea>();
	ListaPrincipalAdapter adapter;
	HorizontalPager realViewSwitcher;

	List<ListView> listaListView = new ArrayList<ListView>();
	List<ListaPrincipalAdapter> listaAdapters = new ArrayList<ListaPrincipalAdapter>();
	List<Tarea> values = new ArrayList<Tarea>();
	//List of dates
	List<Date> fechas = new ArrayList<Date>();
	ListView listaVista;
	//number of screen
	int pantalla = 0;

	/**
	 * When the PrincipalActivity is created, links the HorizontalPager with the application and fill the lists.
	 */
	public void onCreate(Bundle savedInstanceState) {
		realViewSwitcher = new HorizontalPager(getApplicationContext());

		super.onCreate(savedInstanceState);
		
		fillList();

	}

	/**
	 * This function is responsible for fill the tasks lists, separated by days, and display them on screen. 
	 * To accomplish this task retrieves the DB dates that are different, and each of them calls 
	 * the function agregarTareasByFecha
	 * @see #agregarTareasByFecha
	 */
	private void fillList(){
		final DbAdapter dbAdapter = new DbAdapter(this);

		fechas = dbAdapter.getAllFechas();
		List values = new ArrayList();
		if (fechas.size() > 0) {
			for (int i = 0; i < fechas.size(); i++) {
				agregarTareasByFecha(fechas.get(i));
			}
		}

		adapter = new ListaPrincipalAdapter(this, values);
		setContentView(realViewSwitcher);
		realViewSwitcher.setOnScreenSwitchListener(onScreenSwitchListener);
	}
	
	android.widget.AdapterView.OnItemClickListener listener = new android.widget.AdapterView.OnItemClickListener() {
		/**
		 * The method that will be called when a task is selected.
		 */
		public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
				long arg3) {
			// get the selected item
			Tarea tareaSeleccionada = (Tarea) arg0.getAdapter().getItem(
					arg2);
			Toast.makeText(getApplicationContext(),
					tareaSeleccionada.getDescripcion(), Toast.LENGTH_SHORT)
					.show();
			Intent intent = new Intent(getApplicationContext(),
					NuevaTareaActivity.class);
			//Creates a new Bundle to pass all the info about the selected task to the NuevaTareaActivity.
			Bundle bundle = new Bundle();
			bundle.putString("Tarea", tareaSeleccionada.getDescripcion());
			intent.putExtra("ID", new Integer(tareaSeleccionada.getId()));
			intent.putExtra("Fecha", tareaSeleccionada.getFecha());
			intent.putExtras(bundle);

			startActivityForResult(intent, 2);
		}

	};

	/**
	 * Retrieves all tasks for a given date and creates a new ListAdapter (@see #ListaPrincipalAdapter) with them. 
	 * Generates a new ListView with corresponding listener and fill its title-text in its layout with the given date.
	 * 
	 * @param fecha
	 */
	private void agregarTareasByFecha(Date fecha) {
		
		final DbAdapter dbAdapter = new DbAdapter(this);
		
		//gets all the tasks with a given date from de DB
		List<Tarea> listaDeValores = dbAdapter.getAllInfoByFecha(ConversoresUtils
				.convertDateToString(fecha));
		//Puts a new ListAdapter with the data got before in the list of Adapters.
		ListaPrincipalAdapter adapterTemp = new ListaPrincipalAdapter(this, listaDeValores);
		listaAdapters.add(adapterTemp);

		//get the info from the layout list, just to put the listener and change the title with the given date.
		LinearLayout linearLayout = (LinearLayout) getLayoutInflater().inflate(
				R.layout.list, null);
		TextView text = (TextView) linearLayout.findViewById(R.id.textoLista);
		ListView listView = (ListView) linearLayout.findViewById(R.id.lista);
		listView.setOnItemClickListener(listener);
		listView.setAdapter(adapterTemp);
		text.setText(ConversoresUtils.convertDateToString(fecha));
		//Finally just add that in the HoritzontalPager and in the list of ListViews
		realViewSwitcher.addView(linearLayout);
		listaListView.add(listView);
	
	}

	/**
	 * Generates the menu.
	 */
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.menu_principal, menu);
		return true;
	}

	/**
	 * Generates the options of the menu. 
	 * Just one option Add Task : It will redirect to the NuevaTareaActivity to create a new task.
	 */
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.MenuPrincipalOp1:
			Intent intent = new Intent(this, NuevaTareaActivity.class);
			startActivityForResult(intent, 1);
			return true;
		default:
			return super.onOptionsItemSelected(item);
		}
	}

	/**
	 * This method is responsible for making the appropriate logic when NuevaTareaActivity activity is already finished. 
	 * Its mission is to re-display the list again, in the day that the user was previously. 
	 * If that day has no more tasks, clears and displays the previous day having tasks.
	 */
	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		//case 1: has been created one new task or has been modified one.
		//case 2: has been deleted one task
		switch (requestCode) {
		case (1): {
			
			if (resultCode == Activity.RESULT_OK) {
				final DbAdapter dbAdapter = new DbAdapter(this);
				Bundle b = data.getExtras();
				Date fecha = (Date) b.get("Fecha");
				
				//We will look for the date of the task, and if it already exists, we will save the value in the Integer nuevaPantalla
				Integer nuevaPantalla = null;
				for (int i = 0; i < fechas.size(); i++) {
					if (fechas.get(i).equals(fecha)) {
						nuevaPantalla = new Integer(i);
					}
				}
				String fechaString = ConversoresUtils
						.convertDateToString(fecha);
				
				
				if (nuevaPantalla != null) {
					//If it was a date that already exist(nuevaPantalla has value)
					//get the values with that date, and set the focus in that date.
					List<Tarea> values = dbAdapter
							.getAllInfoByFecha(fechaString);
					realViewSwitcher.setCurrentScreen(nuevaPantalla, false);
					ListaPrincipalAdapter adapterTemp = (ListaPrincipalAdapter) listaAdapters
							.get(nuevaPantalla);
					adapterTemp = new ListaPrincipalAdapter(this, values);
					ListView listaTemp = (ListView) listaListView
							.get(nuevaPantalla);
					listaTemp.setAdapter(adapterTemp);
				} else {
					//add the new date in the list of dates(fechas), order it, and remove the views to fill up again.
					//finally, put the focus in the new date.
					fechas.add(fecha);
					Collections.sort(fechas);
					pantalla = fechas.indexOf(fecha);
					realViewSwitcher.removeAllViews();
					
					realViewSwitcher.setCurrentScreen(pantalla, false);
					fillList();
			
				}
			}
			break;
		}
		case (2): {
			if (resultCode == Activity.RESULT_OK) {
				final DbAdapter dbAdapter = new DbAdapter(this);
				//Firsts, check if now there are still tasks in the date from the task deleted.
				List<Tarea> values = dbAdapter
						.getAllInfoByFecha(ConversoresUtils
								.convertDateToString(fechas.get(pantalla)));
				if(values.size()==0){
					//If there aren't tasks for that date, just it's deleted, and the numberOfScreen (pantalla) dicrises just if is more than the actual dates collection.
					fechas.remove(pantalla);
					if(fechas.size()-1<pantalla){
						pantalla--;
					}
					realViewSwitcher.setCurrentScreen(pantalla, false);
				}
				//finally, all the views are removed and filled again.
				realViewSwitcher.removeAllViews();
				fillList();
				
			}
			break;
		}
		}
	}

	/**
	 * Just control the actual screen, setting the global variable pantalla.
	 */
	private final HorizontalPager.OnScreenSwitchListener onScreenSwitchListener = new HorizontalPager.OnScreenSwitchListener() {

		public void onScreenSwitched(final int screen) {
			pantalla = screen;

		}
	};
}
