package com.corvo.blocdenotas.activities;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;

import com.corvo.blocdenotas.R;
import com.corvo.blocdenotas.beans.Tarea;
import com.corvo.blocdenotas.db.DbAdapter;

/**
 * This activity shows a form to create, update or delete a task. Every
 * operation calls DbAdapter (@see DbAdapter) to perform the DB action.
 * 
 * @author Miguel Corvo Diaz
 * @version 0.1.3
 */
public class NuevaTareaActivity extends Activity {

	public static int id;
	private EditText mDateDisplay;
	private Button mPickDate;
	private int mYear;
	private int mMonth;
	private int mDay;

	/**
	 * Creates the form with the text, date and the Send button. If it's an
	 * modify operation, fill this properties with the correct values, and shows
	 * a button called Delete.
	 */
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);

		//Firsts, gets the info(in the bundle) that we have about the selected task.
		Bundle bundle = getIntent().getExtras();
		
		//If it's here because you selected a task-->if clause-->modify
		//If it's here because you selected New button -->else clause--> create
		if (bundle != null && bundle.getString("Tarea") != null
				&& getIntent().getIntExtra("ID", 0) != 0) {
			//Select the layout for modify, and fill the fields with the data.
			setContentView(R.layout.modificar_tarea);
			EditText editText = (EditText) findViewById(R.id.nombreNuevaTarea);
			editText.setText(bundle.getString("Tarea"));
			id = bundle.getInt("ID", 0);
			// get the current date and time
			Date dat = (Date) bundle.get("Fecha");
			Calendar c = new GregorianCalendar();
			c.setTime(dat);
			mYear = c.get(Calendar.YEAR);
			mMonth = c.get(Calendar.MONTH);
			mDay = c.get(Calendar.DAY_OF_MONTH);

		} else {
			//Just get the actual date.
			setContentView(R.layout.nueva_tarea);
			// get the current date and time
			final Calendar c = Calendar.getInstance();
			mYear = c.get(Calendar.YEAR);
			mMonth = c.get(Calendar.MONTH);
			mDay = c.get(Calendar.DAY_OF_MONTH);

		}
		mDateDisplay = (EditText) findViewById(R.id.dateDisplay);
		mPickDate = (Button) findViewById(R.id.pickDate);
		// add a click listener to the select a date button
		mPickDate.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				showDialog(0);
			}
		});

		// to display the current date
		displayDate();

	}

	/**
	 * Put the date in the form with the dd/MM/yyyy format
	 */
	private void displayDate() {
		mDateDisplay.setText(new StringBuilder()
				// Month is 0 based so add 1
				.append(mDay).append("/").append(mMonth + 1).append("/")
				.append(mYear).append(" "));
	}


	/**
	 * Listen until the callback received when the user sets the date in the dialog. Then, call the displayDate method(@see {@link #displayDate()}.
	 */
	private DatePickerDialog.OnDateSetListener mDateSetListener = new DatePickerDialog.OnDateSetListener() {

		public void onDateSet(DatePicker view, int year, int monthOfYear,
				int dayOfMonth) {
			mYear = year;
			mMonth = monthOfYear;
			mDay = dayOfMonth;
			displayDate();
		}
	};

	/**
	 * Create the Dialog to select the task's date.
	 */
	protected Dialog onCreateDialog(int id) {
		switch (id) {
		case 0:
			return new DatePickerDialog(this, mDateSetListener, mYear, mMonth,
					mDay);

		}
		return null;
	}

	/**
	 * The method creates a new Task, with the text and date selected. 
	 * Then calls the DBAdapter to create the new entry in the DB and return OK to the main Activity.
	 * 
	 * @param view
	 */
	public void crearNuevaTarea(View view) {
		// Intent intent = new Intent(this,DisplayMessageActivity.class);

		EditText editText = (EditText) findViewById(R.id.nombreNuevaTarea);

		Intent intent = new Intent();

		final DbAdapter dbAdapter = new DbAdapter(this);
		Tarea tarea = new Tarea(editText.getText().toString());
		Calendar c = new GregorianCalendar(mYear, mMonth, mDay);
		tarea.setFecha(c.getTime());
		intent.putExtra("Fecha", c.getTime());
		dbAdapter.addEntry(tarea);
		setResult(Activity.RESULT_OK, intent);

		finish();
	}

	/**
	 * The method updates a Task with the text and date selected.
	 * Then calls the DBAdapter to create the new entry in the DB and return OK to the main Activity.
	 * 
	 * @param view
	 */
	public void actualizarTarea(View view) {
		// Intent intent = new Intent(this,DisplayMessageActivity.class);

		EditText editText = (EditText) findViewById(R.id.nombreNuevaTarea);

		Intent intent = new Intent();
		setResult(Activity.RESULT_OK, intent);

		final DbAdapter dbAdapter = new DbAdapter(this);
		Tarea tarea = new Tarea(editText.getText().toString());
		tarea.setId(id);
		Calendar c = new GregorianCalendar(mYear, mMonth, mDay);
		tarea.setFecha(c.getTime());
		dbAdapter.updateEntry(tarea);

		finish();
	}

	/**
	 * The method deletes a given Task by its ID.
	 * Then calls the DBAdapter to create the new entry in the DB and return OK to the main Activity.
	 * 
	 * @param view
	 */
	public void borrarTarea(View view) {
		//creates a new Task, sets the selected Id and call the DB to delete it.
		Tarea tarea = new Tarea();
		tarea.setId(id);
		final DbAdapter dbAdapter = new DbAdapter(this);
		dbAdapter.removeEntry(tarea);

		Intent intent = new Intent();
		setResult(Activity.RESULT_OK, intent);

		finish();

	}
}
