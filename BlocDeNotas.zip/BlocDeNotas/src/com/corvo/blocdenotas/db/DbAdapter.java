package com.corvo.blocdenotas.db;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.corvo.blocdenotas.beans.Tarea;
import com.corvo.blocdenotas.utils.ConversoresUtils;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DbAdapter {
	 private static final String DATABASE_NAME = "DemoDatabase.db";
	    private static final String DATABASE_TABLE = "Tareas";
	    private static final int DATABASE_VERSION = 4;
	    
	    // The index (key) 
	    public static final String KEY_ID = "id";
	    
	    // The name and column index of each column in your database.
	    public static final String KEY_NAME = "descripcion";
	    public static final String KEY_SELECCIONADO = "seleccionado";
	    public static final String KEY_FECHA = "fecha";
	    public static final String KEY_ICONO_ID = "icono_id";
	    
	    // SQL Statement to create a new database.
	    private static final String DATABASE_CREATE = "create table "
	            + DATABASE_TABLE + " (" + KEY_ID
	            + " integer primary key autoincrement, " + KEY_NAME
	            + " text not null, " + KEY_FECHA + " text ,"+ KEY_SELECCIONADO + " boolean, " + KEY_ICONO_ID + " integer );";
	    
	    // variable to hold the database instance
	    private SQLiteDatabase db;
	    
	    // Context of the application using the database.
	    private final Context context;
	    // Database open/upgrade helper
	    private myDbHelper dbHelper;

	    public DbAdapter(Context _context) {

	        context = _context;
	        dbHelper = new myDbHelper(context, DATABASE_NAME, null,
	                DATABASE_VERSION);
	    }
	    
	    /**
	     * Open the DB as writable.
	     * @return
	     * @throws SQLException
	     */
	    public DbAdapter open() throws SQLException {
	        db = dbHelper.getWritableDatabase();
	        return this;
	    }

	    /**
	     * Closes the DB.
	     */
	    public void close() {
	        db.close();
	    }

	    /**
	     * Create a new row with the new info of a Task.
	     * 
	     * @param _tarea
	     */
	    public void addEntry(Tarea _tarea) {
	        //Create a new ContentValues to represent my row
	        // and insert it into the database.
	        open();
	        ContentValues values = new ContentValues();
	        values.put(KEY_NAME, _tarea.getDescripcion()); // Contact Name
	        //values.put(KEY_DISPONIBLE, _tarea.isSeleccionado()); // Contact Phone
	        values.put(KEY_FECHA, ConversoresUtils.convertDateToString(_tarea.getFecha()));
	        // Inserting Row
	        db.insert(DATABASE_TABLE, null, values);
	        close(); // Closing database connection
	        //return index;
	    }
	    
	    /**
	     * Deletes a task according to its ID. 
	     * @param _info
	     */
	    public void removeEntry(Tarea _info) {
	    	open();
	        db.delete(DATABASE_TABLE, KEY_ID + " = ?",
	                new String[] { String.valueOf(_info.getId()) });
	        close();
	    }

	    /**
	     * Retrieves a list of all the different dates of existing tasks in the DB.
	     * 
	     * @return list of dates
	     */
	    public List<Date> getAllFechas(){
	    	List<Date> lista = new ArrayList<Date>();
	    	 String selectQuery = "SELECT  fecha, count(*) AS numero FROM " + DATABASE_TABLE + " GROUP BY fecha";
	    	 open();
		        Cursor cursor = db.rawQuery(selectQuery, null);

		        // looping through all rows and adding to list
		        if (cursor.moveToFirst()) {
		            do {
		                lista.add(ConversoresUtils.convertStringToDate(cursor.getString(0)));
		            } while (cursor.moveToNext());
		        }
		        cursor.close();
		        close();

	    	return lista;
	    }
	    
	    /**
	     * Retrieves a list of tasks based on a given date.
	     * 
	     * @param fecha
	     * @return
	     */
	    public List<Tarea> getAllInfoByFecha(String fecha) {
	    	List<Tarea> infoList = new ArrayList<Tarea>();
	        // Select All Query
	        String selectQuery = "SELECT  * FROM " + DATABASE_TABLE + " WHERE fecha = '" + fecha + "'";
	        open();
	        Cursor cursor = db.rawQuery(selectQuery, null);

	        // looping through all rows and adding to list
	        if (cursor.moveToFirst()) {
	            do {
	            	Tarea tarea = new Tarea();
	                tarea.setId(Integer.parseInt(cursor.getString(0)));
	                tarea.setDescripcion(cursor.getString(1));
	                tarea.setSeleccionado("1".equals(cursor.getString(3)));
	                tarea.setFecha(ConversoresUtils.convertStringToDate(cursor.getString(2)));
	                // Adding contact to list
	                infoList.add(tarea);
	            } while (cursor.moveToNext());
	        }
	        cursor.close();
	        close();
	        // return contact list
	        return infoList;
	    	
	    }
	    
	    
	    public List<Tarea> getAllInfo() {
	        List<Tarea> infoList = new ArrayList<Tarea>();
	        // Select All Query
	        String selectQuery = "SELECT  * FROM " + DATABASE_TABLE;
	        open();
	        Cursor cursor = db.rawQuery(selectQuery, null);

	        // looping through all rows and adding to list
	        if (cursor.moveToFirst()) {
	            do {
	            	Tarea tarea = new Tarea();
	                tarea.setId(Integer.parseInt(cursor.getString(0)));
	                tarea.setDescripcion(cursor.getString(1));
	                tarea.setSeleccionado("1".equals(cursor.getString(3)));
	                tarea.setFecha(ConversoresUtils.convertStringToDate(cursor.getString(2)));
	                // Adding contact to list
	                infoList.add(tarea);
	            } while (cursor.moveToNext());
	        }
	        cursor.close();
	        close();
	        // return contact list
	        return infoList;
	    }

	/**
	 * Updates a task with the new info based on its ID.
	 * 
	 * @param _info
	 * @return number of rows updated.
	 */
	    public int updateEntry(Tarea _info) {

	        ContentValues values = new ContentValues();
	        values.put(KEY_NAME, _info.getDescripcion());
	        values.put(KEY_SELECCIONADO, _info.isSeleccionado());

	        // updating row
	        open();
	        int result = db.update(DATABASE_TABLE, values, KEY_ID + " = ?",
	                new String[] { String.valueOf(_info.getId()) });
	        close();
	        return result;
	    }
	    
	    /**
	     * To control the main actions to the DB, as create it or upgrade it.
	     * 
	     * @author Miguel Corvo Diaz
	     * @version 0.1.3
	     */
	    private static class myDbHelper extends SQLiteOpenHelper {
	        public myDbHelper(Context context, String name, CursorFactory factory,
	                int version) {
	            super(context, name, factory, version);
	        }

	        // Called when no database exists in disk and the helper class needs
	        // to create a new one.
	        @Override
	        public void onCreate(SQLiteDatabase _db) {
	            _db.execSQL(DATABASE_CREATE);
	        }

	        // Called when there is a database version mismatch meaning that the
	        // version
	        // of the database on disk needs to be upgraded to the current version.
	        @Override
	        public void onUpgrade(SQLiteDatabase _db, int _oldVersion,
	                int _newVersion) {
	            // Log the version upgrade.
	            Log.w("TaskDBAdapter", "Upgrading from version " + _oldVersion
	                    + " to " + _newVersion
	                    + ", which will destroy all old data");
	            
	            _db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE);
	            // Create a new one.
	            onCreate(_db);
	        }
	    }
	    
}


