package com.corvo.blocdenotas.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


/**
 * Common converters in the application.
 * 
 * @author Miguel Corvo Diaz
 * @version 0.1.3
 */
public class ConversoresUtils {
	private static SimpleDateFormat format = new SimpleDateFormat(
            "dd-MM-yyyy");
	
	public static String convertDateToString(Date fecha){
		return format.format(fecha);
	}
	
	/**
	 * Convert a String into a Date in the dd-MM-yyyy format.
	 * @param fechaString
	 * @return
	 */
	public static Date convertStringToDate(String fechaString){
		Date date; 
		 try {
	            date = format.parse(fechaString);
	     } catch (ParseException e) {
	            date = null;
	     }
		 return date;
	}
}
