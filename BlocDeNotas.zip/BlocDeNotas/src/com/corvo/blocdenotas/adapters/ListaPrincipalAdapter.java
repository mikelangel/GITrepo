package com.corvo.blocdenotas.adapters;

import java.util.List;

import com.corvo.blocdenotas.R;
import com.corvo.blocdenotas.R.drawable;
import com.corvo.blocdenotas.R.id;
import com.corvo.blocdenotas.R.layout;
import com.corvo.blocdenotas.beans.Tarea;
import com.corvo.blocdenotas.db.DbAdapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Its the Adapter for the list in the main Activity.
 * Alternates two colors an for each row shows the text, date and checkbox with the right info.
 * 
 * @author Miguel Corvo Diaz
 * @version 0.1.3
 */
public class ListaPrincipalAdapter extends ArrayAdapter {
	private final Context context;
	private final List<Tarea> values;
	
	 private int[] colors = new int[] { 0x30008000, 0x30008080 };

	 //Temp class to improve the code and don't get the properties every time with the findById.
	 //ViewHolder will be saved in the Tag property and it will be more practical and eficient.
	 static class ViewHolder {
			public TextView text;
			public ImageView image;
			public CheckBox checkbox;
		}

	public ListaPrincipalAdapter(Context context, List<Tarea> values) {
		super(context, R.layout.row, values);
		this.context = context;
		this.values = values;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		View rowView = convertView;
		final DbAdapter dbAdapter = new DbAdapter(context);
		
		//Just to check if it's here because it's creating the row(rowView ==null) or because it was checked the checkbox of a row
		if(rowView == null){
			LayoutInflater inflater = (LayoutInflater) context
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	
			rowView = inflater.inflate(R.layout.row, parent, false);
			
			final ViewHolder viewHolder = new ViewHolder();
			viewHolder.text = (TextView) rowView.findViewById(R.id.label);
			viewHolder.image = (ImageView) rowView.findViewById(R.id.icon);
			viewHolder.checkbox = (CheckBox) rowView.findViewById(R.id.check);
			viewHolder.checkbox
					.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
						// That method will be called when the check of the task is pressed. Updates that in the DB.
						public void onCheckedChanged(CompoundButton buttonView,
								boolean isChecked) {
							Tarea element = (Tarea) viewHolder.checkbox
									.getTag();
							element.setSeleccionado(buttonView.isChecked());
							dbAdapter.updateEntry(element);
						}
					});
			rowView.setTag(viewHolder);
			viewHolder.checkbox.setTag(values.get(position));
		}else {
			((ViewHolder) rowView.getTag()).checkbox.setTag(values.get(position));
		}
		
		
		ViewHolder holder = (ViewHolder) rowView.getTag();	
		
		String descripcion = values.get(position).getDescripcion();
		
		holder.text.setText(descripcion);
		holder.checkbox.setChecked(values.get(position).isSeleccionado());
		//Puts an image in the task. 
		//TODO: Offer the possibility to select the image. Now it will be just depending of the text... change that!
		if (descripcion.startsWith("Warning")) {
			holder.image.setImageResource(R.drawable.amarillo);
		} else if(descripcion.startsWith("Urgent")){
			holder.image.setImageResource(R.drawable.rojo);
		}else{
			holder.image.setImageResource(R.drawable.verde);
		}
		
		int colorPos = position % colors.length;
		
		rowView.setBackgroundColor(colors[colorPos]);

		return rowView;
	}
}
