package com.corvo.blocdenotas.beans;

import java.util.Date;

public class Tarea {

	private int id;

	/** Task Description **/
	private String descripcion;

	/** Indicates if the task is selected or not **/
	private boolean seleccionado;

	/** Date of the Task **/
	private Date fecha;

	public Tarea() {

	}

	public Tarea(String descripcion) {
		super();
		this.descripcion = descripcion;
	}

	/**
	 * Return the ID of the Task.
	 * @return id
	 */
	public int getId() {
		return id;
	}

	/**
	 * Sets the ID of the Task.
	 * @param id
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Returns the date of the Task.
	 * @return date
	 */
	public Date getFecha() {
		return fecha;
	}

	/**
	 * Sets the date of the Task.
	 * @param fecha
	 */
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	/**
	 * Return the text of the Task.
	 * @return
	 */
	public String getDescripcion() {
		return descripcion;
	}

	/**
	 * Sets the text of the Task.
	 * @param descripcion
	 */
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	/**
	 * Return if the Task is selected.
	 * @return true if it's selected. False if it's not.
	 */
	public boolean isSeleccionado() {
		return seleccionado;
	}

	/**
	 * Sets if the Task is selected.
	 * @param seleccionado
	 */
	public void setSeleccionado(boolean seleccionado) {
		this.seleccionado = seleccionado;
	}

}
